package com.example.ex7_24ucs063;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Bundle bun = getIntent().getExtras();

        if (bun != null) {
            String lat = bun.getString("lat");
            String lon = bun.getString("lng");

            WebView web = (WebView) findViewById(R.id.w1);
            WebSettings webSettings = web.getSettings();
            webSettings.setJavaScriptEnabled(true);

            web.setWebViewClient(new WebViewClient());
            web.loadUrl("https://www.google.com/maps?q=" + lat + "," + lon);
        }
    }
}
