package com.example.ex_9;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    EditText e1, e2;
    Button addBtn, subBtn, mulBtn, divBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        e1 = findViewById(R.id.editText1);
        e2 = findViewById(R.id.editText2);
        addBtn = findViewById(R.id.buttonAdd);
        subBtn = findViewById(R.id.buttonSub);
        mulBtn = findViewById(R.id.buttonMul);
        divBtn = findViewById(R.id.buttonDiv);

        addBtn.setOnClickListener(v -> calculate("+"));
        subBtn.setOnClickListener(v -> calculate("-"));
        mulBtn.setOnClickListener(v -> calculate("*"));
        divBtn.setOnClickListener(v -> calculate("/"));
    }
    private void calculate(String op) {
        String s1 = e1.getText().toString().trim();
        String s2 = e2.getText().toString().trim();

        if (s1.isEmpty()) {
            e1.setError("Enter first number");
            return;
        }
        if (s2.isEmpty()) {
            e2.setError("Enter second number");
            return;
        }
        double num1, num2;
            num1 = Double.parseDouble(s1);
            num2 = Double.parseDouble(s2);
        double result = 0;
        switch (op) {
            case "+": result = num1 + num2; break;
            case "-": result = num1 - num2; break;
            case "*": result = num1 * num2; break;
            case "/":
                if (num2 == 0) {
                    showDialog("Cannot divide by zero");
                    return;
                }
                result = num1 / num2; break;
        }
        showDialog("Result: " + result);
    }
    private void showDialog(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Result");
        builder.setMessage(message);
        builder.setPositiveButton("OK", (dialog, which) -> dialog.dismiss());
        builder.show();
    }
}