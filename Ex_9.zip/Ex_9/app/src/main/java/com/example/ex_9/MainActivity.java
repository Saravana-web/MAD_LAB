package com.example.ex_9;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.ex_9.R;

public class MainActivity extends AppCompatActivity {
    Button b1;
    EditText e;
    TextView t;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        e = findViewById(R.id.editText);
        t = findViewById(R.id.textView);
        b1 = findViewById(R.id.button);
        b1.setOnClickListener(v -> {
            String mark = e.getText().toString().trim();
            if (mark.isEmpty()) {
                e.setError("Please enter a mark");
                return;
            }
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("ALERT");
            builder.setMessage("Do you want to submit the test mark?");
            builder.setCancelable(false);
            builder.setPositiveButton("YES", (dialog, which) -> {
                t.setText("Submitted Mark: " + mark);
                dialog.dismiss();
            });
            builder.setNegativeButton("NO", (dialog, which) -> {
                dialog.cancel();
            });
            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        });
    }
}