package com.example.ex_8;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {

    EditText e;
    TextView textView;
    Button w, r;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        e = findViewById(R.id.e);
        textView = findViewById(R.id.textView);
        w = findViewById(R.id.w);
        r = findViewById(R.id.r);

        w.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    File f = new File(getExternalFilesDir(null), "myfile.txt");
                    f.createNewFile();
                    FileOutputStream fos = new FileOutputStream(f);
                    String s = e.getText().toString();
                    fos.write(s.getBytes());
                    fos.close();

                    Toast.makeText(MainActivity.this,
                            "File Written Successfully",
                            Toast.LENGTH_SHORT).show();

                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        r.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    File f = new File(getExternalFilesDir(null), "myfile.txt");
                    String msg="", s="";
                    FileInputStream fin = new FileInputStream(f);
                    BufferedReader br = new BufferedReader(new InputStreamReader(fin));

                    while ((msg = br.readLine()) != null) {
                        s += msg;
                    }
                    textView.setText(s);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });
    }
}