package com.example.ex3;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        TextView t1 = findViewById(R.id.t1);
        TextView t2 = findViewById(R.id.t2);
        ImageView i = findViewById(R.id.i);

        Bitmap bg = Bitmap.createBitmap(720, 1280, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bg);
        Paint p = new Paint();
        i.setImageBitmap(bg);

        c.drawColor(Color.WHITE);

        Bundle b = getIntent().getExtras();
        if (b != null) {
            String name = b.getString("name");
            String shape = b.getString("shapes");

            t1.setText(name);
            t2.setText(shape);

            p.setColor(Color.RED);
            p.setStyle(Paint.Style.FILL);


            if (shape.equals("Rectangle")) {
                c.drawRect(150, 200, 550, 400, p);
            } else if (shape.equals("Circle")) {
                p.setColor(Color.BLACK);
                c.drawCircle(400, 400, 200, p);
            } else if (shape.equals("Triangle")) {
                p.setColor(Color.GREEN);
                Path path = new Path();
                path.moveTo(400, 200);
                path.lineTo(200, 500);
                path.lineTo(600, 500);
                path.close();
                c.drawPath(path, p);
            } else if (shape.equals("House")) {
                drawHouse(c, p);
            }else {
                p.setColor(Color.RED);
                p.setTextSize(80);
                c.drawText("No Shape", 200, 400, p);
            }
          }

        }
    private void drawHouse(Canvas c, Paint p) {

        // House body
        c.drawRect(250, 350, 550, 600, p);

        // Roof
        Paint roofPaint = new Paint();
        roofPaint.setColor(Color.GRAY);
        roofPaint.setStyle(Paint.Style.FILL);
        roofPaint.setAntiAlias(true);

        Path roofPath = new Path();
        roofPath.moveTo(400, 250);
        roofPath.lineTo(220, 350);
        roofPath.lineTo(580, 350);
        roofPath.close();

        c.drawPath(roofPath, roofPaint);

        // Door
        Paint doorPaint = new Paint();
        doorPaint.setColor(Color.BLACK);
        doorPaint.setStyle(Paint.Style.FILL);

        c.drawRect(370, 450, 430, 600, doorPaint);
    }
}
