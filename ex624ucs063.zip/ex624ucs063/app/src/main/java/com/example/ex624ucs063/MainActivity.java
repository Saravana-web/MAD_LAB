package com.example.ex624ucs063;

import android.graphics.drawable.AnimationDrawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    ImageView img;
    Button b1;
    MediaPlayer m1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1 = (Button) findViewById(R.id.button);
        img = (ImageView) findViewById(R.id.imageView);

       m1 = MediaPlayer.create(MainActivity.this, R.raw.aud);

        // Multithreading to play audio and swap images
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        img.post(new Runnable() {
                            @Override
                            public void run() {
                                AnimationDrawable a = new AnimationDrawable();
                                a.addFrame(getResources().getDrawable(R.drawable.img1), 500);
                                a.addFrame(getResources().getDrawable(R.drawable.img2), 500);
                                a.addFrame(getResources().getDrawable(R.drawable.img3), 500);
                                a.addFrame(getResources().getDrawable(R.drawable.img4), 500);
                                a.addFrame(getResources().getDrawable(R.drawable.img5), 500);
                                a.setOneShot(false);
                                img.setBackgroundDrawable(a);
                                a.start();
                            }
                        });
                    }
                }).start();

                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        img.post(new Runnable() {
                            @Override
                            public void run() {
                                m1.start();
                            }
                        });
                    }
                }).start();   // ← Missing start() added here
            }
        });
    }
}

